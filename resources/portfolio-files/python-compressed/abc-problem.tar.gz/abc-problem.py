# General solution idea
# 1*. Present blocks as list (or list with sets): 
     # [A, F, C, K, J, L] or [{A, F}, {C, K}, ...]
# 2. Take a word (str) input and list the letters. 
# 3. Check:
     # - the str has no numbers or special symbols,
     # - case for each letter, and use caps/lows to unify
# 4. Using copies of the lists, iterate.
     # If a letter in word == letter in the blocks >>
     # remove the letter from the word and remove the block pair
# 5. If all the letters in the world are removed >>
     # return True, else return False
# -------------------------------------------------------- #

# Define global variables and import alphabet
import string

alphabet = list(string.ascii_letters)
word_letters = []
blocks = [{'B', 'O'}, {'X', 'K'}, {'D', 'Q'}, {'C', 'P'}, {'N', 'A'}, {'G', 'T'}, {'R', 'E'}, {'T', 'G'}, {'Q', 'D'}, {'F', 'S'}, {'J', 'W'}, {'H', 'U'}, {'V', 'I'}, {'A', 'N'}, {'O', 'B'}, {'E', 'R'}, {'F', 'S'}, {'L', 'Y'}, {'P', 'C'}, {'Z', 'M'}]

#ABC function
def abc_blocks_function(word):
    word_letters.clear() # Reset and initialize the list for a new word
    block_letters = blocks[:] # Create single-use copy of the blocks (= populate the list)

    for symbol in word:
        if symbol in alphabet:
            word_letters.append(symbol.upper())
        else:
            raise ValueError("Please, use Latin alphabet letters only!")
        
    for letter in word_letters[:]: #Iterate through the word and blocks letters to find matches
        found = False
        for pair in block_letters[:]:
            if letter in pair:
                found = True    
                word_letters.remove(letter)
                block_letters.remove(pair)
                break

    if not word_letters:
        print(f"The word '{word}' can be formed! :)")
        return True
    else:
        print(f"The word '{word}' cannot be formed :(")
        return False
                
# Prompt the user to enter a word 
while True:  #Create infinite query loop until the user's request
    try:
        
        word = input("Enter a word (Latin alphabet) + Enter, or 0 (zero)+Enter to quit: ")
        if word == '0' or word == '':
            print("Goodbye!")
            break
        else:
            abc_blocks_function(word)
            
    except Exception as e:
        print("An error occurred:", e)

# ---------------THE END------------------ #

# HOWEVER,
# ! NOTE:
#^ The classic Rosetta Code's ABC problem task provides a specific block set featuring mirrored blocks for any repeated letter.
#^ In other words, in the given pairs, the second occurrence of a letter in a pair {i, j} if exists is always in the mirrored pair {j, i}.
#^ This feature of the given set simplifies the task. If, instead, the pairs were organized differently, such as {i, j} 
#^ and {k, i}, the algorithm would become more complex. In such cases, we would need to check each letter with its 
#^ multiple occurrences, leading to increased complexity in the algorithm due to combinatorial considerations.
#^ For example, given any 10 blocks, we should run the test up to P(10,10) = 10! = 3,628,800 times to determine 
#^ whether the word can be formed using the given pairs.
#^ The next example demonstrates inapplicability of the basic solution of the problem when we use a randomized block set.
#^   Given the following set: [{'D', 'B'}, {'K', 'O'}, {'D', 'J'}, {'A', 'S'}, {'O', 'E'}]. If we test the abstract word 'boda'
#^   against the given set, the program returns 'True', i.e. the word can be formed. However, if we test another abstract word
#^   'doba', composed from the same set of letters, the result is 'False'.
# !  

# Check out the solution for the complex ABC problem: https://mikezolo.github.io/portfolio/resources/portfolio-files/python-compressed/abc-problem-complex.tar.gz
