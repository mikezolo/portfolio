# ABC Problem

## Description
Rosetta Code's [ABC Problem](https://rosettacode.org/wiki/ABC_problem) is a string analysis challenge: create a function to determine if a word can be spelled using provided blocks. Given letters A, B, and C representing distinct digits, find all valid mappings for the equation A + B = C. Solutions showcase logical thinking and problem-solving skills.

## Files
- `abc-problem.py`: Contains the implementation of the solution for the ABC Problem.
- `README.md`: Provides information and instructions for the project.

## Usage
1. Ensure you have Python 3.x installed on your system.
2. Extract the contents of the `abc-problem.tar.gz` archive to a directory of your choice.
3. Open your terminal and navigate to the directory containing the extracted files.
4. Run the program using the following command:

```bash
python3 abc-problem.py

```
5. Follow the on-screen instructions to input a word to be tested against the block set.
The program will continue executing until the user decides to exit by inputting '0' followed by the Enter key.
To test the program, you can use the following suggestions by Rosetta Code:

    >>> "A"
    True
    >>> "BARK"
    True
    >>> "BOOK"
    False
    >>> "TREAT"
    True
    >>> "COMMON"
    False
    >>> "SQUAD"
    True
    >>> "CONFUSE"
    True

## Limitations
The classic Rosetta Code's ABC problem task provides a specific and ordered block set featuring mirrored blocks for any repeated letter.
In other words, in the given pairs, the second occurrence of a letter in a pair {i, j} if exists is always in the mirrored pair {j, i}:
(B O), (X K), (D Q), (C P), (N A), (G T), (R E), (T G), (Q D), (F S), (J W), (H U), (V I), (A N), (O B), (E R), (F S), (L Y), (P C), (Z M).

This feature of the given set simplifies the task. If, instead, the pairs were organized differently, such as {i, j} and {k, i}, the algorithm would become more complex due to the combinatorics issues. In such cases, we would need to check each letter with its multiple occurrences, leading to increased complexity in the algorithm due to combinatorial considerations. For example, given any 10 blocks, we should run the test up to P(10,10) = 10! = 3,628,800 times to determine whether the word can be formed using the given pairs.

The next example demonstrates the non-applicability of the basic solution of the problem when we use a randomized block set.
Given the following set: [{'D', 'B'}, {'K', 'O'}, {'D', 'J'}, {'A', 'S'}, {'O', 'E'}]. If we test the abstract word 'boda' against the given set, the program returns 'True', i.e. the word can be formed. However, if we test another abstract word 'doba', composed of the same set of letters, the result is 'False'.

Check out the solution for the complex ABC problem: https://mikezolo.github.io/portfolio/resources/portfolio-files/python-compressed/abc-problem-complex.tar.gz

## Credits
This program was created by Michael Zolotarenko (2024).
