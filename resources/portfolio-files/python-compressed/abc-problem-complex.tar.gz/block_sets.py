import string
import random

alphabet = list(string.ascii_letters.upper())

def random_blocks(num_blocks):
    random_set = []

    while num_blocks:
        random_pair = random.sample(alphabet, 2)
        if len(set(random_pair)) == 2:
            random_set.append(set(random_pair))
        num_blocks -= 1
    
    print(random_set)
    return random_set
