import csv
import random
from collections import deque, Counter, namedtuple
from time import time, sleep

# Define named tuples for clarity
Wall = namedtuple('Wall', ['x', 'y'])
Goal = namedtuple('Goal', ['x', 'y'])
BotScoreData = namedtuple('BotScoreData', ['name', 'num_moves', 'num_collisions', 'score'])

def read_maze(name):
    maze_chars = []
    with open(name, 'r') as csvfile:
        r = csv.reader(csvfile)
        for row in r:
            maze_chars.append(row)
    return maze_chars

def print_maze(maze_data):
    for row in maze_data:
        print('  '.join(row))
    print('\n')

def is_race_over(bots):
    return all(bot.has_finished for bot in bots)

def print_results(bot_score_data):
    bot_score_data.sort(key=lambda b: b.score, reverse=True)
    print("----- RESULTS -----")
    for place, score_data in enumerate(bot_score_data, start=1):
        print(f"{place}. Robot: {score_data.name}")
        print(f"   Score: {score_data.score} Moves: {score_data.num_moves} Collisions: {score_data.num_collisions}")

def process_maze_init(maze_data):
    walls = []
    goal = None
    bots = []
    for r, row in enumerate(maze_data):
        for c, col in enumerate(row):
            if col == '#':
                walls.append(Wall(c,r))
            elif col == '$':
                goal = Goal(c,r)
            elif col.isalpha():
                bots.append(Robot(c,r, col))
    return walls, goal, bots

def populate_robot_moves(walls, goal, bots, max_turns):
    robot_moves = deque()
    num_of_turns = 0
    while not is_race_over(bots) and num_of_turns < max_turns:
        for bot in bots:
            if not bot.has_finished:
                move = compute_robot_logic(walls, goal, bot)
                robot_moves.append(move)
        num_of_turns += 1
    return robot_moves

def count_moves(robot_moves):
    return Counter(move[0] for move in robot_moves)

def count_collisions(robot_moves):
    return Counter(move[0] for move in robot_moves if move[2])

def calculate_scores(bots, move_counts, collision_counts):
    bot_scores = []
    for bot in bots:
        score_data = BotScoreData(
            name=bot.name,
            num_moves=move_counts[bot.name],
            num_collisions=collision_counts[bot.name],
            score=move_counts[bot.name] + collision_counts[bot.name]
        )
        bot_scores.append(score_data)
    return bot_scores

def move_and_update(robot_moves, bots, maze_data, seconds_between_turns):
    bot_data = {bot.name: bot for bot in bots}
    while robot_moves:
        move = robot_moves.popleft()
        bot = bot_data[move[0]]
        bot.process_move(move[1])
        update_maze_characters(maze_data, bots)
        print_maze(maze_data)
        sleep(seconds_between_turns)

def update_maze_characters(maze_data, bots):
    for r, row in enumerate(maze_data):
        for c, col in enumerate(row):
            if col.isalpha() or col == '+':
                maze_data[r][c] = '_'
    for bot in bots:
        if not bot.remove:
            if maze_data[bot.y][bot.x].isalpha():
                maze_data[bot.y][bot.x] = '+'
            else:
                maze_data[bot.y][bot.x] = bot.name

def calc_manhattan_dist(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)

class Robot:
    def __init__(self, x, y, name):
        self.x = x
        self.calc_x = x
        self.y = y
        self.calc_y = y
        self.has_finished = False
        self.remove = False
        self.name = name

    def process_move(self, direction):
        if direction == 'left':
            self.x -= 1
        elif direction == 'right':
            self.x += 1
        elif direction == 'up':
            self.y -= 1
        elif direction == 'down':
            self.y += 1
        elif direction == 'finished':
            self.remove = True

def compute_robot_logic(walls, goal, bot):
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    move_names = {(-1, 0): 'left', (1, 0): 'right', (0, -1): 'down', (0, 1): 'up', (0, 0): 'nothing'}

    selected_move = moves[random.randint(0,3)]
    move_dist = []
    for m, move in enumerate(moves):
        dist = calc_manhattan_dist(bot.calc_x + move[0], bot.calc_y + move[1], goal.x, goal.y)
        move_dist.append([m,dist])
    move_dist.sort(key=lambda x: x[1])
    if random.random() < 0.45:
        selected_move = moves[move_dist[0][0]]

    hit_wall = False
    for wall in walls:
        if bot.calc_x + selected_move[0] == wall.x and bot.calc_y + selected_move[1] == wall.y:
            hit_wall = True

    found_alternate_move = False
    if hit_wall:
        for next_move in move_dist:
            move = moves[next_move[0]]
            hit_wall_move = False
            for wall in walls:
                if bot.calc_x + move[0] == wall.x and bot.calc_y + move[1] == wall.y:
                    hit_wall_move = True

            if not hit_wall_move:
                selected_move = move
                found_alternate_move = True
                break

        if not found_alternate_move:
            selected_move = (0,0)

    if bot.calc_x + selected_move[0] == goal.x and bot.calc_y + selected_move[1] == goal.y:
        bot.has_finished = True
        bot.calc_x += selected_move[0]
        bot.calc_y += selected_move[1]
        return bot.name, 'finished', hit_wall

    bot.calc_x += selected_move[0]
    bot.calc_y += selected_move[1]
    return bot.name, move_names[selected_move], hit_wall
