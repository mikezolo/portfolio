import robot_race_functions_1 as rr
from time import time, sleep

maze_file_name = 'maze_data_1.csv'
seconds_between_turns = 0.3
max_turns = 35

# Initialize the robot race
maze_data = rr.read_maze(maze_file_name)
rr.print_maze(maze_data)
walls, goal, bots = rr.process_maze_init(maze_data)

# Populate a deque of all robot commands for the provided maze
robot_moves = rr.populate_robot_moves(walls, goal, bots, max_turns)

# Count the number of moves based on the robot names
move_counts = rr.count_moves(robot_moves)

# Count the number of collisions by robot name
collision_counts = rr.count_collisions(robot_moves)

# Calculate the scores (moves + collisions) for each robot
bot_scores = rr.calculate_scores(bots, move_counts, collision_counts)

# Move the robots and update the map based on the moves deque
rr.move_and_update(robot_moves, bots, maze_data, seconds_between_turns)

# Print out the results
rr.print_results(bot_scores)
