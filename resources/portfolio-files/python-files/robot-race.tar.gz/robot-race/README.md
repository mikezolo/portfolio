# Robot Race
 
## Description
The Robot Race program simulates a race between robots in a maze environment. The robots navigate through the maze to reach the goal while avoiding collisions with walls.
 
## Files
- `robot_race_1.py`: Main Python script to run the robot race simulation.
- `robot_race_functions_1.py`: Contains functions for maze processing, robot logic, and scoring.
- `maze_data_1.csv`: CSV file containing maze data for the robot race simulation.
 
## Usage
1. Ensure you have Python 3.x installed on your system.
2. Extract the contents of this archive to a directory of your choice.
3. Open your terminal and navigate to the directory containing the extracted files.
4. Run the program using the following command:
 
python3 robot_race.py
 
If `python3` is not recognized, you can try `python` or `python3.x`, where `x` represents the minor version number of Python 3 installed on your system.
5. Follow the on-screen instructions to view the results of the robot race.
 
## Notes
- Modify `maze_data_1.csv` or create your own maze data files to customize the race environment.
- Feel free to explore and modify the Python scripts to add new features or enhance the simulation.
 
## Credits
This program was created by Codecademy and Michael Zolotarenko (2023)
